package org.yuno.rielitem.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.yuno.rielitem.RielItem;
import org.yuno.rielitem.managers.RielManager;

import java.util.*;
import java.util.stream.Collectors;

public class LoyaltyCommand implements CommandExecutor, TabCompleter {

    private static final List<String> AMOUNTS = Arrays.asList(
        "100", "500", "1000", "5000", "10000", "50000", "100000"
    );
    private static final List<String> SUB_COMMANDS = Arrays.asList(
        "give", "give-all", "withdraw", "balance", "list", "reload"
    );

    private final RielItem plugin;

    public LoyaltyCommand(RielItem plugin) {
        this.plugin = plugin;
    }

    // ─── /loyalty ────────────────────────────────────────────────────────────

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        try {
            if (!hasAdminPermission(sender)) {
                noPerms(sender);
                return true;
            }

            if (args.length == 0) {
                sendHelp(sender);
                return true;
            }

            switch (args[0].toLowerCase()) {
                case "give"     -> handleGive(sender, args);
                case "give-all" -> handleGiveAll(sender, args);
                case "withdraw" -> handleWithdraw(sender, args);
                case "balance"  -> handleBalance(sender);
                case "list"     -> handleList(sender);
                case "reload"   -> handleReload(sender);
                default         -> sendHelp(sender);
            }
        } catch (Exception e) {
            plugin.getLogger().severe("LoyaltyCommand error: " + e.getMessage());
            e.printStackTrace();
        }
        return true;
    }

    // ─── give ────────────────────────────────────────────────────────────────

    private void handleGive(CommandSender sender, String[] args) {
        if (args.length < 3) {
            send(sender, "&e Usage: /loyalty give <player> <amount> [qty]", 0xFFAA00);
            send(sender, "&7 Amounts: 100, 500, 1000, 5000, 10000, 50000, 100000", 0xAAAAAA);
            return;
        }

        Player target = plugin.getServer().getPlayerExact(args[1]);
        if (target == null) {
            String msg = plugin.getConfig().getString("messages.player-not-found", "&c❌ Player not found: &e{player}")
                    .replace("{player}", args[1]);
            send(sender, msg, 0xFF5555);
            return;
        }

        int amount;
        try {
            amount = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            send(sender, "&c Invalid amount! Use: 100, 500, 1000, 5000, 10000, 50000, 100000", 0xFF5555);
            return;
        }

        if (!plugin.getRielManager().getValidAmounts().contains(amount)) {
            String msg = plugin.getConfig().getString("messages.unknown-denomination",
                    "&c❌ Invalid denomination!");
            send(sender, msg, 0xFF5555);
            return;
        }

        int qty = 1;
        if (args.length >= 4) {
            try { qty = Math.max(1, Integer.parseInt(args[3])); }
            catch (NumberFormatException ignored) {}
        }

        try {
            ItemStack item = plugin.getRielManager().createRielItem(amount, qty);
            if (item == null) {
                send(sender, "&c Failed to create item!", 0xFF5555);
                return;
            }
            target.getInventory().addItem(item);

            String formatted = plugin.getRielManager().formatAmount(amount);
            String msg = plugin.getConfig().getString("messages.given",
                    "&a✅ ផ្តល់ &e{amount} ៛ &aទៅ &f{player} &aដោយជោគជ័យ!")
                    .replace("{amount}", formatted)
                    .replace("{player}", target.getName());
            send(sender, msg, 0x55FF55);

            // Sound for receiver
            target.getWorld().playSound(
                target.getLocation(),
                org.bukkit.Sound.ENTITY_ITEM_PICKUP, 1f, 1f
            );
        } catch (Exception e) {
            send(sender, "&c Failed to create item!", 0xFF5555);
            plugin.getLogger().warning("Give error: " + e.getMessage());
        }
    }

    // ─── give-all ────────────────────────────────────────────────────────────

    private void handleGiveAll(CommandSender sender, String[] args) {
        if (args.length < 2) {
            send(sender, "&e Usage: /loyalty give-all <amount> [qty]", 0xFFAA00);
            return;
        }

        int amount;
        try {
            amount = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            send(sender, "&c Invalid amount!", 0xFF5555);
            return;
        }

        if (!plugin.getRielManager().getValidAmounts().contains(amount)) {
            send(sender, "&c Invalid denomination!", 0xFF5555);
            return;
        }

        int qty = 1;
        if (args.length >= 3) {
            try { qty = Math.max(1, Integer.parseInt(args[2])); }
            catch (NumberFormatException ignored) {}
        }

        final int finalQty = qty;
        int count = 0;
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            try {
                ItemStack item = plugin.getRielManager().createRielItem(amount, finalQty);
                if (item != null) {
                    p.getInventory().addItem(item);
                    count++;
                }
            } catch (Exception e) {
                plugin.getLogger().warning("give-all error for " + p.getName() + ": " + e.getMessage());
            }
        }
        send(sender, "&a✅ ផ្តល់ " + plugin.getRielManager().formatAmount(amount)
                + " ៛ ទៅ &f" + count + " &aplayers!", 0x55FF55);
    }

    // ─── withdraw ────────────────────────────────────────────────────────────

    private void handleWithdraw(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            send(sender, "&c Only players!", 0xFF5555);
            return;
        }

        if (args.length < 2) {
            send(sender, "&e Usage: /loyalty withdraw <amount>", 0xFFAA00);
            return;
        }

        if (!plugin.hasEconomy()) {
            String msg = plugin.getConfig().getString("messages.no-vault",
                    "&c❌ Vault / EssentialsX not installed!");
            send(sender, msg, 0xFF5555);
            return;
        }

        int amount;
        try {
            amount = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            send(sender, "&c Invalid amount! Use: 100, 500, 1000, 5000, 10000, 50000, 100000", 0xFF5555);
            return;
        }

        if (!plugin.getRielManager().getValidAmounts().contains(amount)) {
            send(sender, "&c❌ Invalid denomination! Use: 100,500,1000,5000,10000,50000,100000", 0xFF5555);
            return;
        }

        double balance = plugin.getEconomy().getBalance(player);
        if (balance < amount) {
            send(sender, "&c Balance " + plugin.getRielManager().formatAmount(balance)
                    + " ៛ &eមិនគ្រប់គ្រាន់!", 0xFF5555);
            return;
        }

        net.milkbowl.vault.economy.EconomyResponse resp =
                plugin.getEconomy().withdrawPlayer(player, amount);
        if (!resp.transactionSuccess()) {
            send(sender, "&c Denomination " + amount + " failed!", 0xFF5555);
            return;
        }

        try {
            ItemStack item = plugin.getRielManager().createRielItem(amount, 1);
            if (item == null) {
                // Refund
                plugin.getEconomy().depositPlayer(player, amount);
                send(sender, "&c Failed to create riel item!", 0xFF5555);
                return;
            }
            player.getInventory().addItem(item);
            send(sender, "&a✅ ដក &e" + plugin.getRielManager().formatAmount(amount)
                    + " ៛ &aចេញពី Balance!", 0x55FF55);
        } catch (Exception e) {
            plugin.getEconomy().depositPlayer(player, amount);
            send(sender, "&c Error! Balance refunded.", 0xFF5555);
            plugin.getLogger().warning("Withdraw error: " + e.getMessage());
        }
    }

    // ─── balance ─────────────────────────────────────────────────────────────

    private void handleBalance(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            send(sender, "&c Only players!", 0xFF5555);
            return;
        }
        if (!plugin.hasEconomy()) {
            send(sender, plugin.getConfig().getString("messages.no-vault", "&c❌ Vault not found!"), 0xFF5555);
            return;
        }
        double bal = plugin.getEconomy().getBalance(player);
        String msg = plugin.getConfig().getString("messages.balance",
                "&6💰 Balance របស់អ្នក: &e{balance} ៛")
                .replace("{balance}", plugin.getRielManager().formatAmount(bal));
        send(sender, msg, 0xFFAA00);
    }

    // ─── list ────────────────────────────────────────────────────────────────

    private void handleList(CommandSender sender) {
        send(sender, "─── RielItem Denominations ─── LoyaltyMC ───", 0xFFD700);
        for (Map.Entry<Integer, RielManager.DenominationData> entry
                : RielManager.DENOMINATIONS.entrySet()) {
            sender.sendMessage(
                Component.text("  » " + entry.getValue().displayName)
                         .color(TextColor.color(entry.getValue().color))
            );
        }
    }

    // ─── reload ──────────────────────────────────────────────────────────────

    private void handleReload(CommandSender sender) {
        try {
            plugin.reloadConfig();
            send(sender, "&a✅ Config reloaded!", 0x55FF55);
        } catch (Exception e) {
            send(sender, "&c Reload error: " + e.getMessage(), 0xFF5555);
            plugin.getLogger().severe("Reload error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ─── help ────────────────────────────────────────────────────────────────

    private void sendHelp(CommandSender sender, boolean isOp) {
        send(sender, "─── RielItem Commands  LoyaltyMC ───", 0xFFD700);
        send(sender, "/loyalty list              — denominations",        0xAAAAAA);
        send(sender, "/loyalty balance           — balance",              0xAAAAAA);
        send(sender, "/loyalty give <player> <amount> [qty]",             0xAAAAAA);
        send(sender, "/loyalty give-all <amount> [qty]",                  0xAAAAAA);
        send(sender, "/loyalty withdraw <amount>",                        0xAAAAAA);
        send(sender, "/loyalty reload",                                   0xAAAAAA);
    }

    private void sendHelp(CommandSender sender) {
        sendHelp(sender, sender.isOp());
    }

    // ─── helpers ─────────────────────────────────────────────────────────────

    private boolean hasAdminPermission(CommandSender sender) {
        return sender.isOp() || sender.hasPermission("rielitem.admin");
    }

    private void noPerms(CommandSender sender) {
        String msg = plugin.getConfig().getString("messages.no-permission", "&c❌ No permission!");
        send(sender, msg, 0xFF5555);
    }

    private void send(CommandSender sender, String msg, int hex) {
        // Strip legacy colour codes for Component, keep it simple with plain text + colour
        String plain = msg.replaceAll("&[0-9a-fklmnor]", "");
        sender.sendMessage(Component.text(plain).color(TextColor.color(hex)));
    }

    // ─── tab complete ─────────────────────────────────────────────────────────

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command,
                                      String alias, String[] args) {
        if (!hasAdminPermission(sender)) return Collections.emptyList();

        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.addAll(SUB_COMMANDS);
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("give")) {
                // suggest online player names
                plugin.getServer().getOnlinePlayers()
                      .forEach(p -> completions.add(p.getName()));
            } else if (sub.equals("give-all") || sub.equals("withdraw")) {
                completions.addAll(AMOUNTS);
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            completions.addAll(AMOUNTS);
        } else if (args.length == 4 && args[0].equalsIgnoreCase("give")) {
            completions.addAll(Arrays.asList("1", "2", "3", "5", "10", "16", "32", "64"));
        }

        // filter by what user has typed so far
        String typed = args[args.length - 1].toLowerCase();
        return completions.stream()
                .filter(c -> c.toLowerCase().startsWith(typed))
                .collect(Collectors.toList());
    }
}
